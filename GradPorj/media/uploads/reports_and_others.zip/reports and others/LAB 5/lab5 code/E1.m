clear
clc
close all

im1 = imread('Fig1.tif');
e1 = edge(im1,'sobel');
e2 = edge(im1,'prewitt');
e3 = edge(im1,'roberts');
e4 = edge(im1,'log');
e5 = edge(im1,'zerocross');
e6 = edge(im1,'canny');

figure,
subplot(4,2,1), imshow(im1),title('Original Image');
subplot(4,2,2), imshow(e1), title('Sobel Edge Detector');
subplot(4,2,3), imshow(e2), title('Prewitt Edge Detector');
subplot(4,2,4), imshow(e3), title('Roberts Edge Detector');
subplot(4,2,5), imshow(e4), title('Laplacian of Gaussian');
subplot(4,2,6), imshow(e5), title('Zero-Crossings Detector');
subplot(4,2,7), imshow(e6), title('Canny Edge Detector');