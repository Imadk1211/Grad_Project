clear
clc
close all

im1=imread('Fig2.tif');

[M,N] = size(im1);
r = imnoise2('uniform',M,N);
e2=edge(im1,"canny");
e3=edge(im1,"log");

im2=im2double(im1);

noise = immultiply(im2,r);
e2_1 = edge(noise,'log');
e3_1 = edge(noise,'canny');

figure,
subplot(3,2,1), imshow(im1), title('Original Image');
subplot(3,2,2), imshow(e2), title('Canny Edge Detector');
subplot(3,2,3), imshow(noise), title('Noisy Image');
subplot(3,2,4), imshow(e2_1), title('Noisy Canny Edge Detector');
subplot(3,2,5), imshow(e3), title('Marry-Hildreth Edge Detector');
subplot(3,2,6), imshow(e3_1), title('Noisy Marry-Hildreth Edge Detection');
