clear
clc
close all
%E1
%task (a)
im = imread('Fig1.tif');
BW1 = edge(im,'sobel');
BW2 = edge(im,'prewitt');
BW3 = edge(im,'roberts');
BW4 = edge(im,'log');
BW5 = edge(im,'zerocross');
BW6 = edge(im,'canny');

im1 = imread('Fig2.tif');
BW11 = edge(im1,'sobel');
BW22 = edge(im1,'prewitt');
BW33 = edge(im1,'roberts');
BW44 = edge(im1,'log');
BW55 = edge(im1,'zerocross');
BW66 = edge(im1,'canny');

%figure1%
figure,
subplot(3,3,1), imshow(im),title('Original Image');
subplot(3,3,2), imshow(BW1), title('Edge detecting with sobel');
subplot(3,3,3), imshow(BW2), title('Edge detecting with prewitt');
subplot(3,3,4), imshow(BW3), title('Edge detecting with roberts');
subplot(3,3,5), imshow(BW4), title('Edge detecting with laplacian');
subplot(3,3,6), imshow(BW5), title('Edge detecting with zerocross');
subplot(3,3,7), imshow(BW6), title('Edge detecting with canny');

%figure2%
figure,
subplot(3,3,1), imshow(im1),title('Original Image');
subplot(3,3,2), imshow(BW11), title('Edge detecting with sobel');
subplot(3,3,3), imshow(BW22), title('Edge detecting with prewitt');
subplot(3,3,4), imshow(BW33), title('Edge detecting with roberts');
subplot(3,3,5), imshow(BW44), title('Edge detecting with laplacian');
subplot(3,3,6), imshow(BW55), title('Edge detecting with zerocross');
subplot(3,3,7), imshow(BW66), title('Edge detecting with canny');

%task (b) for figure1
[M,N] = size(im);
R = imnoise2('Uniform',M,N);
noisy_image = immultiply(im2double(im),R);
BWLog = edge(noisy_image,'log');
BWCanny = edge(noisy_image,'canny');

R1 = imnoise2('gaussian',M,N);
noisy_image1 = immultiply(im2double(im),R1);
BWLog1 = edge(noisy_image1,'log');
BWCanny1 = edge(noisy_image1,'canny');

R2 = imnoise2('Salt & Pepper',M,N);
noisy_image2 = immultiply(im2double(im),R2);
BWLog2 = edge(noisy_image2,'log');
BWCanny2 = edge(noisy_image2,'canny');

R3 = imnoise2('Lognormal',M,N);
noisy_image3 = immultiply(im2double(im),R3);
BWLog3 = edge(noisy_image3,'log');
BWCanny3 = edge(noisy_image3,'canny');

R4 = imnoise2('Rayleigh',M,N);
noisy_image4 = immultiply(im2double(im),R4);
BWLog4 = edge(noisy_image4,'log');
BWCanny4 = edge(noisy_image4,'canny');

R5 = imnoise2('Exponential',M,N);
noisy_image5 = immultiply(im2double(im),R5);
BWLog5 = edge(noisy_image5,'log');
BWCanny5 = edge(noisy_image5,'canny');

R6 = imnoise2('Erlang',M,N);
noisy_image6 = immultiply(im2double(im),R6);
BWLog6 = edge(noisy_image6,'log');
BWCanny6 = edge(noisy_image6,'canny');


figure,
subplot(7,4,1), imshow(im),title('Orginal Image');
subplot(7,4,2), imshow(noisy_image),title('Uniform Noisy Image');
subplot(7,4,3), imshow(BWLog),title('Edge detecting with Marr-Hildreth');
subplot(7,4,4), imshow(BWCanny),title('Edge detecting with Canny');

subplot(7,4,6), imshow(noisy_image1),title('Gaussian Noisy Image');
subplot(7,4,7), imshow(BWLog1),title('Edge detecting with Marr-Hildreth');
subplot(7,4,8), imshow(BWCanny1),title('Edge detecting with Canny');

subplot(7,4,10), imshow(noisy_image2),title('Salt & Pepper Noisy Image');
subplot(7,4,11), imshow(BWLog2),title('Edge detecting with Marr-Hildreth');
subplot(7,4,12), imshow(BWCanny2),title('Edge detecting with Canny');

subplot(7,4,14), imshow(noisy_image3),title('Lognormal Noisy Image');
subplot(7,4,15), imshow(BWLog3),title('Edge detecting with Marr-Hildreth');
subplot(7,4,16), imshow(BWCanny3),title('Edge detecting with Canny');

subplot(7,4,18), imshow(noisy_image4),title('Rayleigh Noisy Image');
subplot(7,4,19), imshow(BWLog4),title('Edge detecting with Marr-Hildreth');
subplot(7,4,20), imshow(BWCanny4),title('Edge detecting with Canny');

subplot(7,4,22), imshow(noisy_image5),title('Exponential Noisy Image');
subplot(7,4,23), imshow(BWLog5),title('Edge detecting with Marr-Hildreth');
subplot(7,4,24), imshow(BWCanny5),title('Edge detecting with Canny');

subplot(7,4,26), imshow(noisy_image6),title('Erlang Noisy Image');
subplot(7,4,27), imshow(BWLog6),title('Edge detecting with Marr-Hildreth');
subplot(7,4,28), imshow(BWCanny6),title('Edge detecting with Canny');

%task (b) for figure2
[M,N] = size(im1);
R = imnoise2('Uniform',M,N);
noisy_image = immultiply(im2double(im1),R);
BWLog = edge(noisy_image,'log');
BWCanny = edge(noisy_image,'canny');

R1 = imnoise2('gaussian',M,N);
noisy_image1 = immultiply(im2double(im1),R1);
BWLog1 = edge(noisy_image1,'log');
BWCanny1 = edge(noisy_image1,'canny');

R2 = imnoise2('Salt & Pepper',M,N);
noisy_image2 = immultiply(im2double(im1),R2);
BWLog2 = edge(noisy_image2,'log');
BWCanny2 = edge(noisy_image2,'canny');

R3 = imnoise2('Lognormal',M,N);
noisy_image3 = immultiply(im2double(im1),R3);
BWLog3 = edge(noisy_image3,'log');
BWCanny3 = edge(noisy_image3,'canny');

R4 = imnoise2('Rayleigh',M,N);
noisy_image4 = immultiply(im2double(im1),R4);
BWLog4 = edge(noisy_image4,'log');
BWCanny4 = edge(noisy_image4,'canny');

R5 = imnoise2('Exponential',M,N);
noisy_image5 = immultiply(im2double(im1),R5);
BWLog5 = edge(noisy_image5,'log');
BWCanny5 = edge(noisy_image5,'canny');

R6 = imnoise2('Erlang',M,N);
noisy_image6 = immultiply(im2double(im1),R6);
BWLog6 = edge(noisy_image6,'log');
BWCanny6 = edge(noisy_image6,'canny');


figure,
subplot(7,4,1), imshow(im1),title('Orginal Image');
subplot(7,4,2), imshow(noisy_image),title('Uniform Noisy Image');
subplot(7,4,3), imshow(BWLog),title('Edge detecting with Marr-Hildreth');
subplot(7,4,4), imshow(BWCanny),title('Edge detecting with Canny');

subplot(7,4,6), imshow(noisy_image1),title('Gaussian Noisy Image');
subplot(7,4,7), imshow(BWLog1),title('Edge detecting with Marr-Hildreth');
subplot(7,4,8), imshow(BWCanny1),title('Edge detecting with Canny');

subplot(7,4,10), imshow(noisy_image2),title('Salt & Pepper Noisy Image');
subplot(7,4,11), imshow(BWLog2),title('Edge detecting with Marr-Hildreth');
subplot(7,4,12), imshow(BWCanny2),title('Edge detecting with Canny');

subplot(7,4,14), imshow(noisy_image3),title('Lognormal Noisy Image');
subplot(7,4,15), imshow(BWLog3),title('Edge detecting with Marr-Hildreth');
subplot(7,4,16), imshow(BWCanny3),title('Edge detecting with Canny');

subplot(7,4,18), imshow(noisy_image4),title('Rayleigh Noisy Image');
subplot(7,4,19), imshow(BWLog4),title('Edge detecting with Marr-Hildreth');
subplot(7,4,20), imshow(BWCanny4),title('Edge detecting with Canny');

subplot(7,4,22), imshow(noisy_image5),title('Exponential Noisy Image');
subplot(7,4,23), imshow(BWLog5),title('Edge detecting with Marr-Hildreth');
subplot(7,4,24), imshow(BWCanny5),title('Edge detecting with Canny');

subplot(7,4,26), imshow(noisy_image6),title('Erlang Noisy Image');
subplot(7,4,27), imshow(BWLog6),title('Edge detecting with Marr-Hildreth');
subplot(7,4,28), imshow(BWCanny6),title('Edge detecting with Canny');
