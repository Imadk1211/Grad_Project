img1 = imread("Fig1.tif");
img1_negative = intrans(img1,'neg');
figure,
subplot(1,2,1), imshow(img1),title("Original Image");
subplot(1,2,2), imshow(img1_adjust),title("Negative Image");