img1 = imread("Fig1.tif");
img1_adjust = imadjust(img1);
figure,
subplot(1,2,1), imshow(img1),title("Original Image");
subplot(1,2,2), imshow(img1_adjust),title("Adjusted Image");