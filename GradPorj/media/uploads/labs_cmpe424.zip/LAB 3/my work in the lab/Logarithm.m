img2 = imread("Fig2.tif");
img2_logarithm = intrans(img2,'log',2);
figure,
subplot(1,2,1), imshow(img2),title("Original Image");
subplot(1,2,2), imshow(img2_logarithm),title("Logarithm Transformed Image");