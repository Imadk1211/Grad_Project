img1 = imread("Fig1.tif");
img1_stretch = intrans(img1,'stretch',mean2(img1double(img1)),0.1);
figure,
subplot(1,2,1), imshow(img1),title("Original Image");
subplot(1,2,2), imshow(img1_stretch),title("Stretched Image");