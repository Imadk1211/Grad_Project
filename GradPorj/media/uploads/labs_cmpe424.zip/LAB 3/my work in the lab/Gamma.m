img3 = imread("Fig3.tif");
img3_gamma = intrans(img3,'gamma',0.1);
figure,
subplot(1,2,1), imshow(img3),title("Original Image");
subplot(1,2,2), imshow(img3_gamma),title("Gamma Transformed Image");