# Function to retrieve unconsumed input from the file
def unconsumed_input():
    rem = fin.read()
    return rem


# Function for lexical analysis
def lex():
    global next_token
    while True:
        next_token = fin.read(1)  # Read the next character from the file
        if next_token == '\t' or next_token == '\n' or next_token == ' ':
            pass  # Skip whitespace characters
        else:
            break  # Exit the loop when a non-whitespace character is found


# Non-Terminal G, The first one to be called by the program
def G():
    global error
    lex()  # Perform lexical analysis to read the first token
    print('G --> E')
    E()  # Calls the E Non-terminal
    if next_token == '$' and not error:  # Tells the user if the parsing operation was successful or not
        print("------------------------------------")
        print('Parsing Operation was successful')
        print("------------------------------------")
    else:
        print("------------------------------------")
        print('Parsing Operation was a failure')
        print('Unexpected Token:', next_token)
        print('Unconsumed Input:', unconsumed_input())
        print("------------------------------------")


# Non-terminal E
def E():
    global error
    if error:
        return
    print('E --> T R')
    T()  # Calls the T and R Non-terminals
    R()


# Non-terminal R
def R():
    global error
    if error:
        return
    if next_token == '+':  # Rule for addition
        print('R --> + T R')
        lex()
        T()
        R()
    elif next_token == '-': # Rule for subtraction
        print('R --> - T R')
        lex()
        T()
        R()
    else:
        print('R --> e') # Rule for an empty set (epsilon)


# Non-terminal T
def T():
    global error
    if error:
        return
    print('T --> F S')
    F() # Calls the F and S Non-terminals
    S()


# Non-terminal S
def S():
    global error
    if error:
        return
    if next_token == '*':  # Rule for multiplication
        print('S --> * F S')
        lex()
        F()
        S()
    elif next_token == '/':  # Rule for division
        print('S --> / F S')
        lex()
        F()
        S()
    else:
        print('S --> e')  # Rule for empty (epsilon)


# Non-terminal F
def F():
    global error
    if error:
        return
    if next_token == '(':
        print('F --> ( E )')  # Rule for parentheses
        lex()
        E()
        if next_token == ')':
            lex()
        else:
            error = True
            # print('Error: Expected ")" but got', next_token)
    elif next_token in ['a', 'b', 'c', 'd']:
        print('F --> M')  # Rule for variables
        M()
    elif next_token in ['0', '1', '2', '3']:
        print('F --> N')  # Rule for numbers
        N()
    else:
        error = True
        # print('Error: Unexpected Token', next_token)


# Non-terminal M
def M():
    global error
    if error:
        return
    if next_token == 'a' or next_token == 'b' or next_token == 'c' or next_token == 'd':
        print('M --> ', next_token, sep='')  # Rule for individual variables (a,b,c,d)
        lex()
    else:
        error = True
        print('error: unexpected token', next_token)
        print('unconsumed_input', unconsumed_input())


# Non-terminal N
def N():
    global error
    if error:
        return
    if next_token == '0' or next_token == '1' or next_token == '2' or next_token == '3':
        print('N --> ', next_token, sep='')  # Rule for individual numbers (0-3)
        lex()
    else:
        error = True
        print('error: unexpected token', next_token)
        print('unconsumed_input', unconsumed_input())

# Global variables
error = False
next_token = '%'  # Initialize next_token with a default value

if __name__ == '__main__':
    inputfile = ''

    while True:
        print(" ")
        print("------------------------------------")
        print("Parser inputs")
        print("------------------------------------")
        print("1: (a) $")
        print("2: (z)$")
        print("3: 0 +2 * 3/ 1$ ")
        print("4: (a + b) * c / d $")
        print("5: e =a+ d$")
        print("6: 3 + a - 7$")
        print("7: (3+3 )* (1 /a) -2 $")
        print("8: (4a /34)*3c ^ 2 =5 $")
        print("9: (7b*21d) -a $")
        print("10: (3*b+3) +2*0 - 3/(2-c) *(c/1) $")

        print("------------------------------------")
        inputnumber = input("Enter a number: ")
        print("------------------------------------")

        error = False

        # Open the corresponding input file based on user input
        if inputnumber == '1':
            fin = open('input1.txt', 'r')
            G()
        elif inputnumber == '2':
            fin = open('input2.txt', 'r')
            G()
        elif inputnumber == '3':
            fin = open('input3.txt', 'r')
            G()
        elif inputnumber == '4':
            fin = open('input4.txt', 'r')
            G()
        elif inputnumber == '5':
            fin = open('input5.txt', 'r')
            G()
        elif inputnumber == '6':
            fin = open('input6.txt', 'r')
            G()
        elif inputnumber == '7':
            fin = open('input7.txt', 'r')
            G()
        elif inputnumber == '8':
            fin = open('input8.txt', 'r')
            G()
        elif inputnumber == '9':
            fin = open('input9.txt', 'r')
            G()
        elif inputnumber == '10':
            fin = open('input10.txt', 'r')
            G()
        elif inputnumber.lower() == "end":
            print("The program has closed")
            break
        else:
            print("Error: Enter a valid number")
            print("------------------------------------")

    #fin = open(inputfile, 'r')
    # G()
